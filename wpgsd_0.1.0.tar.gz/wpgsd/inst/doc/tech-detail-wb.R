## ----message = FALSE, warning = FALSE-----------------------------------------
library(tibble)
library(gt)
library(gsDesign)
library(dplyr)
library(wpgsd)

## -----------------------------------------------------------------------------
k <- 2 # Number of total analysis
n_hypotheses <- 3 # Number of hypotheses

## -----------------------------------------------------------------------------
obs_tbl <- tribble(
  ~hypothesis, ~analysis, ~obs_p,
  "H1", 1, 0.02,
  "H2", 1, 0.01,
  "H3", 1, 0.006,
  "H1", 2, 0.015,
  "H2", 2, 0.012,
  "H3", 2, 0.004
) %>%
  mutate(obs_Z = -qnorm(obs_p))

obs_tbl %>%
  gt() %>%
  tab_header(title = "Nominal p-values")

p_obs_IA <- (obs_tbl %>% filter(analysis == 1))$obs_p
p_obs_FA <- (obs_tbl %>% filter(analysis == 2))$obs_p

## -----------------------------------------------------------------------------
alpha <- 0.025
event_tbl <- tribble(
  ~population, ~analysis, ~event,
  "A positive", 1, 80,
  "B positive", 1, 88,
  "AB positive", 1, 64,
  "overall", 1, 180,
  "A positive", 2, 160,
  "B positive", 2, 176,
  "AB positive", 2, 128,
  "overall", 2, 360,
)

## -----------------------------------------------------------------------------
IF_IA <- c(
  ((event_tbl %>% filter(analysis == 1, population == "A positive"))$event + (event_tbl %>% filter(analysis == 1, population == "overall"))$event) /
    ((event_tbl %>% filter(analysis == 2, population == "A positive"))$event + (event_tbl %>% filter(analysis == 2, population == "overall"))$event),
  ((event_tbl %>% filter(analysis == 1, population == "B positive"))$event + (event_tbl %>% filter(analysis == 1, population == "overall"))$event) /
    ((event_tbl %>% filter(analysis == 2, population == "B positive"))$event + (event_tbl %>% filter(analysis == 2, population == "overall"))$event),
  ((event_tbl %>% filter(analysis == 1, population == "AB positive"))$event + (event_tbl %>% filter(analysis == 1, population == "overall"))$event) /
    ((event_tbl %>% filter(analysis == 2, population == "AB positive"))$event + (event_tbl %>% filter(analysis == 2, population == "overall"))$event)
)

IF_IA

## -----------------------------------------------------------------------------
m <- matrix(c( # Transition matrix
  0, 3 / 7, 4 / 7,
  3 / 7, 0, 4 / 7,
  1 / 2, 1 / 2, 0
), nrow = 3, byrow = TRUE)

w <- c(0.3, 0.3, 0.4) # Initial weights

## -----------------------------------------------------------------------------
name_hypotheses <- c(
  "H1: Biomarker A positive",
  "H2: Biomarker B positive",
  "H3: Overall Population"
)

hplot <- gMCPLite::hGraph(
  3,
  alphaHypotheses = w, m = m,
  nameHypotheses = name_hypotheses, trhw = .2, trhh = .1,
  digits = 5, trdigits = 3, size = 5, halfWid = 1, halfHgt = 0.5,
  offset = 0.2, trprop = 0.4,
  fill = as.factor(c(2, 3, 1)),
  palette = c("#BDBDBD", "#E0E0E0", "#EEEEEE"),
  wchar = "w"
)
hplot

## -----------------------------------------------------------------------------
# Get weights for all intersection hypotheses
graph <- gMCPLite::matrix2graph(m)
graph <- gMCPLite::setWeights(graph, w)

## -----------------------------------------------------------------------------
# Set up hypothetical p-values (0 or 1) to obtain all combinations
pvals <- NULL
for (i in 1:n_hypotheses) {
  if (i == 1) {
    pvals <- data.frame(x = c(0, 1))
    names(pvals) <- paste("pval_H", i, sep = "")
  } else {
    tmp <- data.frame(x = c(0, 1))
    names(tmp) <- paste("pval_H", i, sep = "")
    pvals <- merge(pvals, tmp)
  }
}
# Get the weights for each intersection hypothesis
inter_weight <- NULL # Create an empty table to store the weight of interaction hypotheses
for (i in seq_len(nrow(pvals))) { # Each row in `pvals` is 1 possible interaction hypothesis
  pval_tmp <- as.numeric(pvals[i, ])
  graph_tmp <- gMCPLite::gMCP(graph = graph, pvalues = pval_tmp, alpha = alpha)
  weight_tmp <- gMCPLite::getWeights(graph_tmp)
  inter_weight <- dplyr::bind_rows(inter_weight, weight_tmp)
}

inter_weight <- replace(inter_weight, pvals == 0, NA) # Replace the empty hypothesis as NA
inter_weight <- inter_weight[-1, ] # Delete the first row since it is empty set

inter_weight %>%
  gt() %>%
  tab_header("Weight of all possible interaction hypothesis")

## -----------------------------------------------------------------------------
# Event count of intersection of paired hypotheses - Table 2
# H1, H2: Hypotheses intersected.
# (1, 1) represents counts for hypothesis 1
# (1, 2) for counts for the intersection of hypotheses 1 and 2
event <- tribble(
  ~H1, ~H2, ~Analysis, ~Event,
  1, 1, 1, event_tbl %>% filter(analysis == 1, population == "A positive") %>% select(event) %>% as.numeric(),
  2, 2, 1, event_tbl %>% filter(analysis == 1, population == "B positive") %>% select(event) %>% as.numeric(),
  3, 3, 1, event_tbl %>% filter(analysis == 1, population == "overall") %>% select(event) %>% as.numeric(),
  1, 2, 1, event_tbl %>% filter(analysis == 1, population == "AB positive") %>% select(event) %>% as.numeric(),
  1, 3, 1, event_tbl %>% filter(analysis == 1, population == "A positive") %>% select(event) %>% as.numeric(),
  2, 3, 1, event_tbl %>% filter(analysis == 1, population == "B positive") %>% select(event) %>% as.numeric(),
  1, 1, 2, event_tbl %>% filter(analysis == 2, population == "A positive") %>% select(event) %>% as.numeric(),
  2, 2, 2, event_tbl %>% filter(analysis == 2, population == "B positive") %>% select(event) %>% as.numeric(),
  3, 3, 2, event_tbl %>% filter(analysis == 2, population == "overall") %>% select(event) %>% as.numeric(),
  1, 2, 2, event_tbl %>% filter(analysis == 2, population == "AB positive") %>% select(event) %>% as.numeric(),
  1, 3, 2, event_tbl %>% filter(analysis == 2, population == "A positive") %>% select(event) %>% as.numeric(),
  2, 3, 2, event_tbl %>% filter(analysis == 2, population == "B positive") %>% select(event) %>% as.numeric()
)
event

# Generate correlation from events
corr <- wpgsd::generate_corr(event)
corr %>% round(2)

## -----------------------------------------------------------------------------
w_H1 <- 1

# Index to select from the correlation matrix
indx <- grep("H1", colnames(corr))
corr_H1 <- corr[indx, indx]

# Boundary for a single hypothesis across k for the intersection hypothesis
pval_H1 <- 1 - pnorm(gsDesign::gsDesign(
  k = k,
  test.type = 1,
  usTime = IF_IA[1],
  n.I = corr_H1[, ncol(corr_H1)]^2,
  alpha = alpha * w_H1[1],
  sfu = sfHSD,
  sfupar = -4
)$upper$bound)

ans <- tibble(
  Analysis = 1:2,
  `Interaction/Elementary hypotheses` = "H1",
  `H1 p-value boundary` = pval_H1,
  `H2 p-value boundary` = NA,
  `H3 p-value boundary` = NA
)
ans %>% gt()

## -----------------------------------------------------------------------------
w_H2 <- 1

# Index to select from the correlation matrix
indx <- grep("H2", colnames(corr))
corr_H2 <- corr[indx, indx]

# Boundary for a single hypothesis across k for the intersection hypothesis
pval_H2 <- 1 - pnorm(gsDesign::gsDesign(
  k = k,
  test.type = 1,
  usTime = IF_IA[2],
  n.I = corr_H2[, ncol(corr_H2)]^2,
  alpha = alpha * w_H2[1],
  sfu = sfHSD,
  sfupar = -4
)$upper$bound)

ans_new <- tibble(
  Analysis = 1:2,
  `Interaction/Elementary hypotheses` = "H2",
  `H1 p-value boundary` = NA,
  `H2 p-value boundary` = pval_H2,
  `H3 p-value boundary` = NA
)
ans_new %>% gt()
ans <- rbind(ans, ans_new)

## -----------------------------------------------------------------------------
w_H3 <- 1

# Index to select from the correlation matrix
indx <- grep("H3", colnames(corr))
corr_H3 <- corr[indx, indx]

# Boundary for a single hypothesis across k for the intersection hypothesis
pval_H3 <- 1 - pnorm(gsDesign::gsDesign(
  k = k,
  test.type = 1,
  usTime = IF_IA[3],
  n.I = corr_H3[, ncol(corr_H3)]^2,
  alpha = alpha * w_H3[1],
  sfu = sfHSD,
  sfupar = -4
)$upper$bound)

ans_new <- tibble(
  Analysis = 1:2,
  `Interaction/Elementary hypotheses` = "H3",
  `H1 p-value boundary` = NA,
  `H2 p-value boundary` = NA,
  `H3 p-value boundary` = pval_H1
)
ans_new %>% gt()
ans <- rbind(ans, ans_new)

## -----------------------------------------------------------------------------
w_H12 <- inter_weight %>% filter(!is.na(H1), !is.na(H2), is.na(H3))
w_H12 <- w_H12[(!is.na(w_H12))] # Remove NA from weight
w_H12

## -----------------------------------------------------------------------------
# -------------#
#      H1      #
# -------------#
# Index to select from the correlation matrix
indx <- grep("H1", colnames(corr))
corr_H1 <- corr[indx, indx]

# Boundary for a single hypothesis across k for the intersection hypothesis
pval_H1 <- 1 - pnorm(gsDesign::gsDesign(
  k = k,
  test.type = 1,
  usTime = IF_IA[1],
  n.I = corr_H1[, ncol(corr_H1)]^2,
  alpha = alpha * w_H12[1], # alpha is different since the weight is updated
  sfu = sfHSD,
  sfupar = -4
)$upper$bound)

# -------------#
#      H2      #
# -------------#
# Index to select from the correlation matrix
indx <- grep("H2", colnames(corr))
corr_H2 <- corr[indx, indx]

# Boundary for a single hypothesis across k for the intersection hypothesis
pval_H2 <- 1 - pnorm(gsDesign::gsDesign(
  k = k,
  test.type = 1,
  usTime = IF_IA[2],
  n.I = corr_H2[, ncol(corr_H2)]^2,
  alpha = alpha * w_H12[2], # alpha is different since the weight is updated
  sfu = sfHSD,
  sfupar = -4
)$upper$bound)

ans_new <- tibble(
  Analysis = 1:2,
  `Interaction/Elementary hypotheses` = "H1, H2",
  `H1 p-value boundary` = pval_H1,
  `H2 p-value boundary` = pval_H2,
  `H3 p-value boundary` = NA
)
ans_new %>% gt()
ans <- rbind(ans, ans_new)

## -----------------------------------------------------------------------------
w_H13 <- inter_weight %>% filter(!is.na(H1), is.na(H2), !is.na(H3))
w_H13 <- w_H13[(!is.na(w_H13))] # Remove NA from weight
w_H13

## -----------------------------------------------------------------------------
# -------------#
#      H1      #
# -------------#
# Index to select from the correlation matrix
indx <- grep("H1", colnames(corr))
corr_H1 <- corr[indx, indx]

# Boundary for a single hypothesis across k for the intersection hypothesis
pval_H1 <- 1 - pnorm(gsDesign::gsDesign(
  k = k,
  test.type = 1,
  usTime = IF_IA[1],
  n.I = corr_H1[, ncol(corr_H1)]^2,
  alpha = alpha * w_H13[1], # alpha is different since the weight is updated
  sfu = sfHSD,
  sfupar = -4
)$upper$bound)

# -------------#
#      H3      #
# -------------#
# Index to select from the correlation matrix
indx <- grep("H3", colnames(corr))
corr_H3 <- corr[indx, indx]

# Boundary for a single hypothesis across k for the intersection hypothesis
pval_H3 <- 1 - pnorm(gsDesign::gsDesign(
  k = k,
  test.type = 1,
  usTime = IF_IA[3],
  n.I = corr_H3[, ncol(corr_H3)]^2,
  alpha = alpha * w_H13[2], # alpha is different since the weight is updated
  sfu = sfHSD,
  sfupar = -4
)$upper$bound)

ans_new <- tibble(
  Analysis = 1:2,
  `Interaction/Elementary hypotheses` = "H1, H3",
  `H1 p-value boundary` = pval_H1,
  `H2 p-value boundary` = NA,
  `H3 p-value boundary` = pval_H3
)
ans_new %>% gt()
ans <- rbind(ans, ans_new)

## -----------------------------------------------------------------------------
w_H23 <- inter_weight %>% filter(is.na(H1), !is.na(H2), !is.na(H3))
w_H23 <- w_H23[(!is.na(w_H23))] # Remove NA from weight
w_H23

## -----------------------------------------------------------------------------
# -------------#
#      H2      #
# -------------#
# Index to select from the correlation matrix
indx <- grep("H2", colnames(corr))
corr_H2 <- corr[indx, indx]

# Boundary for a single hypothesis across k for the intersection hypothesis
pval_H2 <- 1 - pnorm(gsDesign::gsDesign(
  k = k,
  test.type = 1,
  usTime = IF_IA[2],
  n.I = corr_H2[, ncol(corr_H2)]^2,
  alpha = alpha * w_H23[1], # alpha is different since the weight is updated
  sfu = sfHSD,
  sfupar = -4
)$upper$bound)

# -------------#
#      H3      #
# -------------#
# Index to select from the correlation matrix
indx <- grep("H3", colnames(corr))
corr_H3 <- corr[indx, indx]

# Boundary for a single hypothesis across k for the intersection hypothesis
pval_H3 <- 1 - pnorm(gsDesign::gsDesign(
  k = k,
  test.type = 1,
  usTime = IF_IA[3],
  n.I = corr_H3[, ncol(corr_H3)]^2,
  alpha = alpha * w_H23[2], # alpha is different since the weight is updated
  sfu = sfHSD,
  sfupar = -4
)$upper$bound)

ans_new <- tibble(
  Analysis = 1:2,
  `Interaction/Elementary hypotheses` = "H2, H3",
  `H1 p-value boundary` = NA,
  `H2 p-value boundary` = pval_H2,
  `H3 p-value boundary` = pval_H3
)
ans_new %>% gt()
ans <- rbind(ans, ans_new)

## -----------------------------------------------------------------------------
w_H123 <- inter_weight %>% filter(!is.na(H1), !is.na(H2), !is.na(H3))
w_H123 <- w_H123[(!is.na(w_H123))] # Remove NA from weight
w_H123

## -----------------------------------------------------------------------------
# -------------#
#      H1      #
# -------------#
# Index to select from the correlation matrix
indx <- grep("H1", colnames(corr))
corr_H1 <- corr[indx, indx]

# Boundary for a single hypothesis across k for the intersection hypothesis
pval_H1 <- 1 - pnorm(gsDesign::gsDesign(
  k = k,
  test.type = 1,
  usTime = IF_IA[1],
  n.I = corr_H1[, ncol(corr_H1)]^2,
  alpha = alpha * w_H123[1], # alpha is different since the weight is updated
  sfu = sfHSD,
  sfupar = -4
)$upper$bound)

# -------------#
#      H2      #
# -------------#
# Index to select from the correlation matrix
indx <- grep("H2", colnames(corr))
corr_H2 <- corr[indx, indx]

# Boundary for a single hypothesis across k for the intersection hypothesis
pval_H2 <- 1 - pnorm(gsDesign::gsDesign(
  k = k,
  test.type = 1,
  usTime = IF_IA[2],
  n.I = corr_H2[, ncol(corr_H2)]^2,
  alpha = alpha * w_H123[1], # alpha is different since the weight is updated
  sfu = sfHSD,
  sfupar = -4
)$upper$bound)

# -------------#
#      H3      #
# -------------#
# Index to select from the correlation matrix
indx <- grep("H3", colnames(corr))
corr_H3 <- corr[indx, indx]

# Boundary for a single hypothesis across k for the intersection hypothesis
pval_H3 <- 1 - pnorm(gsDesign::gsDesign(
  k = k,
  test.type = 1,
  usTime = IF_IA[3],
  n.I = corr_H3[, ncol(corr_H3)]^2,
  alpha = alpha * w_H123[3], # alpha is different since the weight is updated
  sfu = sfHSD,
  sfupar = -4
)$upper$bound)

ans_new <- tibble(
  Analysis = 1:2,
  `Interaction/Elementary hypotheses` = "H1, H2, H3",
  `H1 p-value boundary` = pval_H1,
  `H2 p-value boundary` = pval_H2,
  `H3 p-value boundary` = pval_H3
)
ans_new %>% gt()
ans <- rbind(ans, ans_new)

## -----------------------------------------------------------------------------
ans %>%
  mutate(
    `H1 Z-statistics boundary` = -qnorm(`H1 p-value boundary`),
    `H1 Z-statistics boundary` = -qnorm(`H2 p-value boundary`),
    `H1 Z-statistics boundary` = -qnorm(`H3 p-value boundary`)
  ) %>%
  arrange(Analysis, `Interaction/Elementary hypotheses`) %>%
  gt() %>%
  tab_header("p-values/Z-statistics boundaries of weighted Bonferroni")

## -----------------------------------------------------------------------------
generate_bounds(
  type = 0,
  k = 2,
  w = w,
  m = m,
  corr = corr,
  alpha = 0.025,
  sf = list(sfHSD, sfHSD, sfHSD),
  sfparm = list(-4, -4, -4),
  t = list(c(0.5, 1), c(0.5, 1), c(0.5, 1))
) %>% gt()

